package myThreads;
public class PrinterThread implements Runnable{
	String mesaj;
	public PrinterThread(String mesaj){
		this.mesaj=mesaj;
	}
	public void run(){
		while(true)
			System.out.println(mesaj);
	}
}