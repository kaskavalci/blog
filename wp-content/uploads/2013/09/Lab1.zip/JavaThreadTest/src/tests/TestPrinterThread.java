package tests;
import myThreads.PrinterThread;

public class TestPrinterThread{
	public static void main(String arg[])
	{
		PrinterThread n1=new PrinterThread("merhaba");
		PrinterThread n2=new PrinterThread("nasilsin");
		Thread t1=new Thread(n1);
		Thread t2=new Thread(n2);
		t1.start();
		t2.start();
	}
}