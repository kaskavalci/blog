import java.io.OutputStream;
import java.io.PrintStream;

public class WriteToScreen1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String s = "Hello World";
		// OutputStream out=System.out;
		// PrintStream ps= new PrintStream(out);
		// �stteki iki satir yerine alttaki bir satir
		PrintStream ps = System.out;
		ps.println(s);

	}

}
