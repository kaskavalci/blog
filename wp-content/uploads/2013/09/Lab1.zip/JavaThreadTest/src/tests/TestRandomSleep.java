package tests;
import myThreads.ThreadSleepRandom;


public class TestRandomSleep {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ThreadSleepRandom tc = new ThreadSleepRandom("Thread No : 1");
		tc.start();
		
		new ThreadSleepRandom("Thread No : 2").start();
	}

}
