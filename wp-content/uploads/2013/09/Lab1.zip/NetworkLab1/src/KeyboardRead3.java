import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class KeyboardRead3 {

	/**
	 * Konsol input stream'� DataInputStream olarak ds'e atad�k.
	 * Buradan InputStreamReader olu�turduk.
	 * Buffered okuyabilmek i�in de BufferedReader olu�turduk.
	 * @param args
	 */
	public static void main(String[] args) {
		DataInputStream ds = new DataInputStream(System.in);
		BufferedReader bReader = new BufferedReader(new InputStreamReader(ds));
		// system.in inputstream t�r�nde
		try {
			String s = bReader.readLine();
			System.out.println(s);
		} catch (IOException io) {
			// TODO: handle exception
		}

	}

}
