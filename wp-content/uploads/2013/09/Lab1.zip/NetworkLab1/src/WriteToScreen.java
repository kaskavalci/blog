import java.io.IOException;
import java.io.OutputStream;

public class WriteToScreen {

	/**
	 * Konsol output stream'� OutputStream olarak ald�k.
	 * Byte array nas�l olu�turulur
	 * Byte array nas�l ekrana bas�l�r
	 * @param args
	 */
	public static void main(String[] args) {
		OutputStream out = System.out;
		byte b[] = { 'a', 'b', 'c' };
		String s = "Hello World";
		byte str[] = s.getBytes();

		try {
			out.write(str);
			out.flush();

		} catch (IOException io) {
			// TODO: handle exception
		}

	}

}
