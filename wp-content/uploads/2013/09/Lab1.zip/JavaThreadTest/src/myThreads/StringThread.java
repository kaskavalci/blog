package myThreads;
public class StringThread implements Runnable {
	private String str;
	private int num;

	public StringThread(String s, int n) {
		str = new String(s);
		num = n;
		Thread t = new Thread(this);
		t.start();
	}

	public void run() {
		for (int i = 1; i <= num; i++)
			System.out.print(str + " ");
	}
}