import java.io.IOException;

public class KeyboardRead2 {

	/**
	 * read methodu tek bir karakter okur ve integer d�nd�r�r. 
	 * StringBuffer insert ve append method lar� ile String olu�turur.
	 * @param args
	 */
	public static void main(String[] args) {
		StringBuffer stringBuffer = new StringBuffer();
		try {
			char c;
			while ((c = (char) System.in.read()) != '\n') {
				stringBuffer.append(c);
				System.out.println(stringBuffer);
			}
		} catch (IOException io) {
			// TODO: handle exception
		}
	}

}
