import java.io.IOException;

public class KeyboardRead {

	/**
	 * read methodu arguman olarak byte array alarak i�ini dolduruyor. 
	 * Sonras�nda byte array'den String olu�turup bunu println'e veriyoruz.
	 * @param args
	 */
	public static void main(String[] args) {
		byte a[] = new byte[256];
		System.out.println("Bir C�mle Giriniz");
		try {
			System.in.read(a);
			String s = new String(a);
			System.out.println(s);

		} catch (IOException io) {
			// TODO: handle exception
		}
	}

}
