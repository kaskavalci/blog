package tests;
import myThreads.StringThread;

class TestStringThread 
{
    public static void main (String args [] ) 
    {
        new StringThread("Java",50 );
    }
}

